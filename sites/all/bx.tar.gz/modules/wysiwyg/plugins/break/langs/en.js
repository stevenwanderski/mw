// $Id: en.js,v 1.1 2008/06/10 18:20:14 sun Exp $

tinyMCE.addToLang('break', {
  title: 'Insert teaser break',
  desc: 'Separate teaser and body of this content'
});

