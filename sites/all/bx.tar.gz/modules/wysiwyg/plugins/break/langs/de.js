// $Id: de.js,v 1.1 2008/06/15 17:28:15 sun Exp $

tinyMCE.addToLang('break', {
  title: 'Anrisstext trennen',
  desc: 'Separiert den Anrisstext und Textkörper des Inhalts an dieser Stelle'
});

