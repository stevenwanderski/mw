// $Id: es.js,v 1.1 2008/10/25 13:35:51 sun Exp $

tinyMCE.addToLang('break', {
  title: 'Insertar marcador de documento recortado',
  desc: 'Generar el punto de separación entre la versión recortada del documento y el resto del contenido'
});

